using System;

namespace TEXTRPG_TEST
{

    public class INFO
    {
        public string strName;
        public int iHp;
        public int iAttack;
    }
}